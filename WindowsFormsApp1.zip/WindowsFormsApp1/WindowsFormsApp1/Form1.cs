﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            int n;
            int m;
            string inputN = textBoxN.Text;
            string inputM = textBoxM.Text;
            bool resultN = int.TryParse(inputN, out n);
            if (!resultN || n <= 1)
            {
                MessageBox.Show($"Введите число больше 1", "Ошибка");
                return;
            }

            bool resultM = int.TryParse(inputM, out m);
            if (!resultM || m <= 1)
            {
                MessageBox.Show($"Введите число больше 1", "Ошибка");
                return;
            }

            grid.RowCount = n;
            grid.ColumnCount = m;

            var ran = new Random();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    grid.Rows[i].Cells[j].Value = ran.Next(-20, 21);
                }
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            var count = grid.ColumnCount;
            int k;
            string inputK = textBoxK.Text;
            bool resultN = int.TryParse(inputK, out k);
            if (!resultN || k < 1 || k > count)
            {
                MessageBox.Show($"Введите число больше 1 и меньше {count}", "Ошибка");
                return;
            }
            grid.Columns.RemoveAt(k - 1);
        }
    }
}
